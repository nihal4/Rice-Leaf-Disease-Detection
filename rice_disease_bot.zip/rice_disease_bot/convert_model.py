#!/usr/bin/env python3
# =============================================================================
# convert_model.py — One-time conversion: .keras → .onnx
#
# Run this ONCE before starting the bot:
#   python convert_model.py
#
# Requirements for conversion only (not needed to run the bot):
#   pip install tensorflow>=2.16.0 tf2onnx onnx
#
# After conversion, the bot only needs onnxruntime (no TensorFlow).
# =============================================================================

import sys
import os

KERAS_MODEL_PATH = "models/rice_disease_resnet50.keras"
ONNX_MODEL_PATH  = "models/rice_disease_resnet50.onnx"


def main():
    # ------------------------------------------------------------------ #
    # Check source file exists
    # ------------------------------------------------------------------ #
    if not os.path.isfile(KERAS_MODEL_PATH):
        print(f"\n❌ Model file not found: {KERAS_MODEL_PATH}")
        print("Place your trained .keras file in the models/ folder first.\n")
        sys.exit(1)

    print(f"\n🔄 Converting: {KERAS_MODEL_PATH} → {ONNX_MODEL_PATH}")
    print("This may take a minute…\n")

    # ------------------------------------------------------------------ #
    # Import TensorFlow (only needed for conversion)
    # ------------------------------------------------------------------ #
    try:
        import tensorflow as tf
        print(f"✅ TensorFlow {tf.__version__} found")
    except ImportError:
        print("❌ TensorFlow not installed.")
        print("Install it just for conversion:")
        print("  pip install tensorflow>=2.16.0 tf2onnx onnx\n")
        sys.exit(1)

    try:
        import tf2onnx
        import onnx
        print(f"✅ tf2onnx {tf2onnx.__version__} found")
    except ImportError:
        print("❌ tf2onnx / onnx not installed.")
        print("  pip install tf2onnx onnx\n")
        sys.exit(1)

    # ------------------------------------------------------------------ #
    # Load the Keras model
    # ------------------------------------------------------------------ #
    print(f"\n📦 Loading Keras model…")
    try:
        model = tf.keras.models.load_model(KERAS_MODEL_PATH)
        print(f"   Input shape : {model.input_shape}")
        print(f"   Output shape: {model.output_shape}")
    except Exception as e:
        print(f"❌ Failed to load Keras model: {e}")
        sys.exit(1)

    # ------------------------------------------------------------------ #
    # Convert to ONNX
    # ------------------------------------------------------------------ #
    print(f"\n⚙️  Converting to ONNX…")
    try:
        input_signature = [
            tf.TensorSpec(model.input_shape, tf.float32, name="input")
        ]
        onnx_model, _ = tf2onnx.convert.from_keras(
            model,
            input_signature=input_signature,
            opset=13,
            output_path=ONNX_MODEL_PATH,
        )
        print(f"\n✅ Conversion complete!")
        print(f"   Saved to: {ONNX_MODEL_PATH}")
        size_mb = os.path.getsize(ONNX_MODEL_PATH) / (1024 * 1024)
        print(f"   File size: {size_mb:.1f} MB")
    except Exception as e:
        print(f"❌ Conversion failed: {e}")
        sys.exit(1)

    # ------------------------------------------------------------------ #
    # Quick validation
    # ------------------------------------------------------------------ #
    print(f"\n🔍 Validating ONNX model…")
    try:
        import onnxruntime as ort
        import numpy as np
        session = ort.InferenceSession(ONNX_MODEL_PATH, providers=["CPUExecutionProvider"])
        dummy = np.zeros((1, 224, 224, 3), dtype=np.float32)
        input_name  = session.get_inputs()[0].name
        output_name = session.get_outputs()[0].name
        result = session.run([output_name], {input_name: dummy})
        print(f"   Output shape: {result[0].shape}  ✅")
        print(f"\n🎉 Model is ready! You can now run the bot:")
        print(f"   python bot.py\n")
    except ImportError:
        print("   (Install onnxruntime to validate: pip install onnxruntime)")
    except Exception as e:
        print(f"⚠️  Validation warning: {e}")
        print("   The model may still work — try running bot.py\n")


if __name__ == "__main__":
    main()
