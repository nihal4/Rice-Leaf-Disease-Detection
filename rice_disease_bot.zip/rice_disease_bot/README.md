# 🌾 Rice Leaf Disease Classification Telegram Bot

A Telegram bot that classifies rice leaf diseases from photos using a trained
ResNet50 model and provides treatment advice in **Bangla** via the Gemini API.

---

## ✨ Features

| Feature | Detail |
|---|---|
| 🤖 Model | ResNet50 trained on 5 rice disease classes |
| 🌐 Language | All responses in Bangla |
| 💬 Platform | Telegram (python-telegram-bot v20+) |
| 🧠 AI Advice | Google Gemini 1.5 Flash (free tier) |
| ⚡ Performance | Model loaded once at startup |
| 👥 Multi-user | Handles many users simultaneously |

---

## 🦠 Supported Disease Classes

| # | Class | Bangla |
|---|---|---|
| 0 | Bacterial_Leaf_Blight | ব্যাকটেরিয়াল লিফ ব্লাইট |
| 1 | Brown_Spot | ব্রাউন স্পট |
| 2 | Healthy | সুস্থ পাতা |
| 3 | Rice_Hispa | রাইস হিস্পা |
| 4 | Leaf_Blast | লিফ ব্লাস্ট |

---

## 📁 Project Structure

```
rice_disease_bot/
├── bot.py                 ← Main bot (handlers, startup)
├── predictor.py           ← ResNet50 model loading & inference
├── gemini_advisor.py      ← Gemini API integration
├── config.py              ← All configuration variables
├── requirements.txt       ← Python dependencies
├── .env.example           ← Environment variable template
├── models/
│   ├── rice_disease_resnet50.keras   ← Your trained model (add this)
│   └── class_indices.json            ← Class index mapping
└── README.md
```

---

## 🚀 Setup Guide

### Step 1 — Clone / download the project

```bash
git clone <repo-url>
cd rice_disease_bot
```

### Step 2 — Create a virtual environment (recommended)

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### Step 3 — Install dependencies

```bash
pip install -r requirements.txt
```

> **Note:** TensorFlow installation can take a few minutes.
> On Apple Silicon Macs, use `tensorflow-macos` instead.

### Step 4 — Get a Telegram Bot Token

1. Open Telegram and search for **@BotFather**
2. Send `/newbot` and follow the prompts
3. Copy the token that looks like: `123456789:ABCdef...`

### Step 5 — Get a Gemini API Key (free)

1. Go to **https://aistudio.google.com/**
2. Sign in with your Google account
3. Click **"Get API Key"** → **"Create API key"**
4. Copy the key

### Step 6 — Place your trained model

Copy your trained model file into the `models/` folder:

```
models/
├── rice_disease_resnet50.keras   ← place here
└── class_indices.json            ← already included
```

### Step 7 — Configure the bot

**Option A — Edit config.py directly:**

```python
TELEGRAM_BOT_TOKEN = "123456789:ABCdef..."
GEMINI_API_KEY     = "AIzaSy..."
```

**Option B — Use a .env file (recommended for security):**

```bash
cp .env.example .env
# Then edit .env with your real values
```

### Step 8 — Run the bot

```bash
python bot.py
```

You should see:
```
🌾 Rice Disease Bot is running! Press Ctrl+C to stop.
```

---

## 📱 How to Use the Bot

1. Open Telegram and search for your bot by its username
2. Send `/start` to see the welcome message
3. Take a clear photo of a rice leaf (place it on white paper)
4. Send the photo to the bot
5. Wait a few seconds for the disease analysis and treatment advice

---

## ⚙️ Configuration Reference

| Variable | Default | Description |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | — | Your bot token from @BotFather |
| `GEMINI_API_KEY` | — | Your Google AI Studio API key |
| `MODEL_PATH` | `models/rice_disease_resnet50.keras` | Path to trained model |
| `CLASS_INDICES_PATH` | `models/class_indices.json` | Path to class mapping |
| `IMAGE_SIZE` | `(224, 224)` | Input size for ResNet50 |
| `MAX_IMAGE_SIZE_MB` | `10` | Maximum photo size in MB |
| `CONFIDENCE_THRESHOLD` | `0.5` | Below this, warn user about low confidence |

---

## 📊 Console Logging

Every prediction is logged to the console:

```
2024-01-15 10:30:45 [INFO] bot: [2024-01-15 10:30:45] user_id=123456 | disease=Leaf_Blast | confidence=94.2%
```

---

## 🔧 Troubleshooting

| Problem | Solution |
|---|---|
| `Model file not found` | Make sure `.keras` file is in `models/` folder |
| `TELEGRAM_BOT_TOKEN is not set` | Fill in config.py or .env file |
| `Gemini API error` | Bot uses fallback advice automatically |
| Bot not responding | Check your internet connection and bot token |
| Slow first prediction | Normal — model warms up on first run |

---

## 🌐 Deployment Options

### Local (Development)
```bash
python bot.py
```

### Linux Server (Production)
```bash
# Run in background with nohup
nohup python bot.py > bot.log 2>&1 &

# Or use screen
screen -S ricebot
python bot.py
# Ctrl+A, D to detach
```

### systemd Service (Ubuntu/Debian)
Create `/etc/systemd/system/ricebot.service`:
```ini
[Unit]
Description=Rice Disease Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/path/to/rice_disease_bot
ExecStart=/path/to/venv/bin/python bot.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
```
Then:
```bash
sudo systemctl enable ricebot
sudo systemctl start ricebot
```

---

## ⚠️ Disclaimer

This bot provides AI-generated advice for informational purposes only.
For serious crop disease problems, always consult a qualified agricultural expert
or your local agricultural extension office.

---

## 📞 Support

For serious disease outbreaks, contact:
- **Bangladesh Agricultural Research Institute (BARI)**
- **Local Upazila Agricultural Office**
- **DAE Hotline: 16123**
